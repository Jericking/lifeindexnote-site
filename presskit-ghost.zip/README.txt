Life Index Note press kit / 라이프인덱스노트 프레스킷
Contact: support@lifeindexnote.com
Web: https://lifeindexnote.com/press  (English: https://lifeindexnote.com/en-press)

[칼퇴 디펜스 / Kaltoe Defense]
- 부장님 피해서 18시 정각에 퇴근하는 랜덤 머지 디펜스 (Android, 무료, 2026-11-03 출시)
- Dodge the boss and clock out at 6 PM sharp in a random merge defense (Android, free, released Nov 3, 2026)
- https://play.google.com/store/apps/details?id=com.jeric.kaltoedefense

[고스트 모드 / Ghost Mode]
- 단톡방 알림 폭탄에서 탈출, 대신 답장해 주는 앱 (Android, 무료, 2026-11 출시)
- Escape group chat overload with an app that replies for you (Android, free, released Nov 2026)
- https://play.google.com/store/apps/details?id=com.jeric.ghostmode

이미지·영상은 기사, 리뷰, 영상 제작에 자유롭게 사용할 수 있어요.
Images and videos may be used freely for articles, reviews and videos.
